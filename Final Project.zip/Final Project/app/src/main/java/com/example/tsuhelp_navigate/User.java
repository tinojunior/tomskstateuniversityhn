package com.example.tsuhelp_navigate;

public class User
{
    public String fullName, email, faculty;

    public User(){


    }
    public User(String fullName, String email, String faculty)
    {
        this.fullName = fullName;
        this.email = email;
        this.faculty = faculty;
    }


}
