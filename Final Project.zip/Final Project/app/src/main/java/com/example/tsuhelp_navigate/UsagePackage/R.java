package com.example.tsuhelp_navigate.UsagePackage;

class R
{
    public static Object layout;
}
