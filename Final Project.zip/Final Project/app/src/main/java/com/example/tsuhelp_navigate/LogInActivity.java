package com.example.tsuhelp_navigate;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class LogInActivity extends AppCompatActivity implements View.OnClickListener
{

    private TextView register_nav;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        register_nav = (TextView) findViewById(R.id.reg_nav_text);
        register_nav.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        switch(v.getId()) {
            case R.id.reg_nav_text:
                startActivity((new Intent(this, RegistrationActivity.class)));
                break;
        }

    }
}
