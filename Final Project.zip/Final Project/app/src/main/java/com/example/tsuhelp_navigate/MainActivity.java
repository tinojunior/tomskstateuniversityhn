package com.example.tsuhelp_navigate;


import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toolbar;

import com.example.tsuhelp_navigate.UsagePackage.EventsActivity;
import com.example.tsuhelp_navigate.UsagePackage.HelpActivity;
import com.example.tsuhelp_navigate.UsagePackage.NewsActivity;
import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {


    //Variables

    DrawerLayout drawerLayout;
    NavigationView navigationView;
    Toolbar toolbar;

    @SuppressLint("UseSupportActionBar")
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        toolbar = findViewById(R.id.toolbar);

        setActionBar(toolbar);


        // Hide or Show Items(Logout and Login)

        Menu menu = navigationView.getMenu();
        menu.findItem(R.id.nav_logout).setVisible(false);
        menu.findItem(R.id.nav_profile).setVisible(false);

        navigationView.bringToFront();
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
        drawerLayout.addDrawerListener(toggle);
        toggle.syncState();

        navigationView.setNavigationItemSelectedListener(this);

        navigationView.setCheckedItem(R.id.nav_home);
    }

    //To avoid the application closing when back button is pressed
    //After a tap it should navigate back the side bar menu and show the main tabs which include news and events etc.

    @Override
    public void onBackPressed()
    {

        if(drawerLayout.isDrawerOpen(GravityCompat.START))
        {
            drawerLayout.closeDrawer(GravityCompat.START);
        }
        else
        {
            super.onBackPressed();
        }
        super.onBackPressed();
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem menuItem)
    {

        switch (menuItem.getItemId())
        {
            //We are already in the Home as we start the application
            case R.id.nav_home:
                break;

                //Navigation to the news page
            case R.id.nav_news:
                Intent intent = new Intent(MainActivity.this, NewsActivity.class);
                startActivity(intent);
                break;

                //Nav to the events page
            case R.id.nav_events:
                Intent intent1 = new Intent(MainActivity.this, EventsActivity.class);
                startActivity(intent1);
                break;

                //Nav to the help page

            case R.id.nav_help:

            case R.id.nav_contact:
                Intent intent2 = new Intent(MainActivity.this, HelpActivity.class);
                startActivity(intent2);
                break;

            case R.id.nav_donate:
                break;

            case R.id.nav_navigate:
                break;

            //Now within the profile

            case R.id.nav_login:
                Intent intent4 = new Intent(MainActivity.this, LogInActivity.class);
                startActivity(intent4);
                break;

            case R.id.nav_profile:
                break;

            case R.id.nav_logout:
                Intent intent5 = new Intent((MainActivity.this), SplashActivity.class);
                startActivity(intent5);
                break;

            //Now within the communication part

        }
        drawerLayout.closeDrawer(GravityCompat.START);

        return true;
    }
}

